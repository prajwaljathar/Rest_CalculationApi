/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.controller;

/**
 *
 * @author prajwal.j
 */
import com.main.studentdetail.Studentdetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/calculation")
public class CalculationController {

    @PostMapping("/additionresult")
    public int addition(@RequestBody Studentdetails studentdetails) {
        studentdetails.getvalue1();
        studentdetails.getvalue2();
        return studentdetails.getvalue1() + studentdetails.getvalue2();
    }

    @PostMapping("/substractionresult")
    public int substraction(@RequestBody Studentdetails studentdetails) {
        studentdetails.getvalue1();
        studentdetails.getvalue2();
        return studentdetails.getvalue1() - studentdetails.getvalue2();
    }

    @PostMapping("/multiplicationresult")
    public int multiplication(@RequestBody Studentdetails studentdetails) {
        studentdetails.getvalue1();
        studentdetails.getvalue2();
        return studentdetails.getvalue1() * studentdetails.getvalue2();
    }

    @PostMapping("/divisionresult")
    public int division(@RequestBody Studentdetails studentdetails) {
        studentdetails.getvalue1();
        studentdetails.getvalue2();
        return studentdetails.getvalue1() / studentdetails.getvalue2();
    }

      

}
