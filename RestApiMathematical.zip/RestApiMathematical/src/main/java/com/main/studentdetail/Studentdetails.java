/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.studentdetail;

/**
 *
 * @author prajwal.j
 */

public class Studentdetails {

    private int value1;
 
    private int value2;

    public Studentdetails() {

    }

    public Studentdetails(int value1, int value2) {
        super();
        this.value1 = value1;
        
        this.value2 = value2;
        
        
    }

    public int getvalue1() {
        return value1;
    }

    public void setvalue1(int value1) {
        this.value1 = value1;
    }

  

    public int getvalue2() {
        return value2;
    }

    public void setfees(int value2) {
        this.value2 = value2;
        
    }


}
